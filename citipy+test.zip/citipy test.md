

```python
from citipy import citipy
import pandas as pd
import numpy as np
import json 
import requests
import matplotlib.pyplot as plt
```


```python
# Generate latitudes(-90 to 90) and longitudes(-180 to 180) using random number generator and multiply by 100
cities_df=pd.DataFrame({"long":(np.random.uniform(-1.8,1.8,1200)*100), "lat":(np.random.uniform(-0.9,0.9,1200)*100)})

cities_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>lat</th>
      <th>long</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>-15.935698</td>
      <td>-61.089880</td>
    </tr>
    <tr>
      <th>1</th>
      <td>-69.686479</td>
      <td>-84.076501</td>
    </tr>
    <tr>
      <th>2</th>
      <td>8.419977</td>
      <td>136.372507</td>
    </tr>
    <tr>
      <th>3</th>
      <td>-59.209376</td>
      <td>-89.475420</td>
    </tr>
    <tr>
      <th>4</th>
      <td>61.592274</td>
      <td>-131.843796</td>
    </tr>
  </tbody>
</table>
</div>




```python
cities_name=[]
countrycode=[]
for i in range(0,len(cities_df['lat'])):
    lat=cities_df.iloc[i]['lat']
    long=cities_df.iloc[i]["long"]
    city=citipy.nearest_city(lat,long)
    name=city.city_name
    cities_name.append(name)
    country=city.country_code
    countrycode.append(country)
    
cities_df['City']=cities_name
cities_df['Country']=countrycode
cities_df.head(10)
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>lat</th>
      <th>long</th>
      <th>City</th>
      <th>Country</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>-15.935698</td>
      <td>-61.089880</td>
      <td>san ignacio</td>
      <td>bo</td>
    </tr>
    <tr>
      <th>1</th>
      <td>-69.686479</td>
      <td>-84.076501</td>
      <td>punta arenas</td>
      <td>cl</td>
    </tr>
    <tr>
      <th>2</th>
      <td>8.419977</td>
      <td>136.372507</td>
      <td>airai</td>
      <td>pw</td>
    </tr>
    <tr>
      <th>3</th>
      <td>-59.209376</td>
      <td>-89.475420</td>
      <td>punta arenas</td>
      <td>cl</td>
    </tr>
    <tr>
      <th>4</th>
      <td>61.592274</td>
      <td>-131.843796</td>
      <td>whitehorse</td>
      <td>ca</td>
    </tr>
    <tr>
      <th>5</th>
      <td>64.212479</td>
      <td>-177.111221</td>
      <td>egvekinot</td>
      <td>ru</td>
    </tr>
    <tr>
      <th>6</th>
      <td>28.544978</td>
      <td>14.651332</td>
      <td>hun</td>
      <td>ly</td>
    </tr>
    <tr>
      <th>7</th>
      <td>5.511463</td>
      <td>-11.133907</td>
      <td>monrovia</td>
      <td>lr</td>
    </tr>
    <tr>
      <th>8</th>
      <td>11.724702</td>
      <td>60.004389</td>
      <td>salalah</td>
      <td>om</td>
    </tr>
    <tr>
      <th>9</th>
      <td>-7.250444</td>
      <td>-38.176167</td>
      <td>itaporanga</td>
      <td>br</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Drop duplicate cities in 'City'
new_cities = cities_df.drop_duplicates("City", keep='first')
```


```python
api_key="4c28215f1c71887e12ca92c10a6ac317"

new_cities["Max Temp"]=""
new_cities["Humidity"]= ""
new_cities["Cloud Cover"] = ""
new_cities["Wind Speed"] = ""
new_cities["Date"]=""
new_cities.head()

```

    C:\Users\sitra\Anaconda3\envs\PythonData\lib\site-packages\ipykernel_launcher.py:3: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      This is separate from the ipykernel package so we can avoid doing imports until
    C:\Users\sitra\Anaconda3\envs\PythonData\lib\site-packages\ipykernel_launcher.py:4: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      after removing the cwd from sys.path.
    C:\Users\sitra\Anaconda3\envs\PythonData\lib\site-packages\ipykernel_launcher.py:5: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      """
    C:\Users\sitra\Anaconda3\envs\PythonData\lib\site-packages\ipykernel_launcher.py:6: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      
    C:\Users\sitra\Anaconda3\envs\PythonData\lib\site-packages\ipykernel_launcher.py:7: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      import sys
    




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>lat</th>
      <th>long</th>
      <th>City</th>
      <th>Country</th>
      <th>Max Temp</th>
      <th>Humidity</th>
      <th>Cloud Cover</th>
      <th>Wind Speed</th>
      <th>Date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>-15.935698</td>
      <td>-61.089880</td>
      <td>san ignacio</td>
      <td>bo</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th>1</th>
      <td>-69.686479</td>
      <td>-84.076501</td>
      <td>punta arenas</td>
      <td>cl</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th>2</th>
      <td>8.419977</td>
      <td>136.372507</td>
      <td>airai</td>
      <td>pw</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th>4</th>
      <td>61.592274</td>
      <td>-131.843796</td>
      <td>whitehorse</td>
      <td>ca</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th>5</th>
      <td>64.212479</td>
      <td>-177.111221</td>
      <td>egvekinot</td>
      <td>ru</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
  </tbody>
</table>
</div>




```python
# Loop through the cities_pd and run a weather search for each city
for index, row in new_cities.iterrows():
        target_url="http://api.openweathermap.org/data/2.5/weather?q=%s&units=IMPERIAL&mode=json&APPID=%s" % (row["City"].replace(" ","+"), api_key)
        cities_weather = requests.get(target_url).json()
        print(target_url)

        try:
            new_cities.set_value(index, "Max Temp", cities_weather["main"]["temp_max"])
            new_cities.set_value(index, "Humidity", cities_weather["main"]["humidity"])
            new_cities.set_value(index, "Cloud Cover", cities_weather["clouds"]["all"])
            new_cities.set_value(index, "Wind Speed", cities_weather["wind"]["speed"])
            new_cities.set_value(index, "Date", cities_weather["dt"])
        except:
            print("Missing city weather data.......skipping")                                                               
    
                    
# Turn columns to numeric because of empty rows
new_cities["Max Temp"] = pd.to_numeric(new_cities["Max Temp"], errors='coerce')
new_cities["Humidity"] = pd.to_numeric(new_cities["Humidity"], errors='coerce')
new_cities["Cloud Cover"] = pd.to_numeric(new_cities["Cloud Cover"], errors='coerce')
new_cities["Wind Speed"] = pd.to_numeric(new_cities["Wind Speed"], errors='coerce')

new_cities.head()




```

    http://api.openweathermap.org/data/2.5/weather?q=san+ignacio&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=punta+arenas&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=airai&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=whitehorse&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=egvekinot&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=hun&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=monrovia&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=salalah&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=itaporanga&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=bamboo&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=belushya+guba&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=hobyo&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=arraial+do+cabo&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=barrow&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=kuche&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=neiafu&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=shache&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=new+norfolk&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=bengkulu&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=popondetta&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=thompson&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=bredasdorp&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=mataura&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=hobart&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=georgetown&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=luderitz&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=puerto+ayora&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=aksha&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=dhidhdhoo&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=nanakuli&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=mar+del+plata&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=kousseri&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=mount+pleasant&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=dalhousie&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=yellowknife&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=rikitea&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=albany&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=quatre+cocos&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=kapaa&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=tautira&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=torbay&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=dikson&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=asayita&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=paraiso&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=nizhneyansk&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=koutsouras&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=coquimbo&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=turukhansk&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=forestville&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=paamiut&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=busselton&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=muisne&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=port+hedland&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=lorengau&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=tual&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=sumbawa&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=biak&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=ngukurr&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=tessalit&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=caxito&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=paita&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=vila+velha&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=jamestown&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=ushuaia&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=port+alfred&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=jega&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=hilo&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=taitung&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=cockburn+town&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=mae+hong+son&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=yaan&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=kodiak&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=saint-pierre&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=kerema&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=kondinskoye&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=villa+bruzual&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=homa+bay&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=omaruru&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=chacabuco&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=simpang&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=tuktoyaktuk&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=rungata&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=puerto+escondido&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=saint-philippe&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=barentsburg&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=nikolskoye&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=miramar&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=hermanus&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=araouane&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=illoqqortoormiut&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=lakatoro&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=taolanaro&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=la+asuncion&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=hovd&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=hauterive&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=hami&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=tabou&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=norman+wells&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=cape+town&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=vaini&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=buin&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=yatou&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=amderma&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=nouakchott&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=sanbu&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=atuona&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=brae&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=tasiilaq&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=hithadhoo&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=esso&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=baniyas&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=pospelikha&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=ponta+do+sol&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=elizabeth+city&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=port+hardy&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=bluff&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=geraldton&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=chuy&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=jalu&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=dingle&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=upernavik&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=agva&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=sivas&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=mahebourg&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=xghajra&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=bethel&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=chokurdakh&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=aksarka&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=mundargi&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=lubango&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=avarua&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=port+blair&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=moron&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=klyuchevskiy&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=samusu&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=saskylakh&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=meyungs&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=mount+isa&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=college&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=gumdag&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=bilibino&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=ancud&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=qaanaaq&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=los+llanos+de+aridane&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=saldanha&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=wajir&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=kaitangata&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=morondava&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=cherskiy&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=itarema&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=longyearbyen&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=suwannaphum&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=henties+bay&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=mascote&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=fairbanks&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=provideniya&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=karratha&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=lompoc&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=caravelas&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=mayumba&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=east+london&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=canton&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=tura&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=igdir&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=attawapiskat&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=lebu&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=bayji&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=sinnamary&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=miracema+do+tocantins&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=castro&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=kavieng&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=qandala&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=mys+shmidta&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=haibowan&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=yar-sale&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=impfondo&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=lubao&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=butaritari&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=katsuura&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=poum&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=dimona&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=corowa&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=baghmara&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=kabala&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=the+valley&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=shymkent&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=tahe&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=chunhuhub&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=yulara&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=faya&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=tilichiki&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=galiwinku&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=tecoanapa&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=mandera&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=emba&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=bambous+virieux&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=umzimvubu&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=broome&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=maraa&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=tiksi&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=yinchuan&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=karkaralinsk&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=fecamp&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=mombasa&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=anchorage&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=belaya+gora&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=inuvik&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=rawson&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=innisfail&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=cancun&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=sabha&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=great+falls&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=agadez&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=iqaluit&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=te+anau&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=faanui&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=houlton&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=shingu&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=vardo&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=dossor&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=barinas&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=kentau&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=vanimo&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=kahului&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=hit&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=cayenne&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=husavik&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=northam&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=gao&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=sinkat&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=kendari&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=cidreira&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=grand+river+south+east&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=hanko&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=mount+gambier&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=solnechnyy&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=spassk-dalniy&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=kytlym&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=nizhneangarsk&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=bandarbeyla&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=marcona&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=port+elizabeth&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=sainthia&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=lugovoy&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=paradwip&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=camana&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=huarmey&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=chapais&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=pevek&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=svetlogorsk&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=puerto+baquerizo+moreno&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=kruisfontein&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=abnub&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=riyadh&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=san+rafael&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=avera&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=corpus+christi&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=narsaq&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=gejiu&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=ballina&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=ilulissat&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=podgornoye&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=chaozhou&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=deputatskiy&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=jinchang&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=toliary&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=havre-saint-pierre&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=chamba&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=sorland&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=nanortalik&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=kelvington&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=arroyo&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=amalapuram&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=namatanai&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=roebourne&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=wilmington+island&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=gurgentepe&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=adrar&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=vetlanda&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=vila+franca+do+campo&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=beringovskiy&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=pangkalanbuun&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=ribeira+grande&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=savannakhet&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=saint+george&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=champua&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=moerai&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=mouzakion&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=hamilton&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=terra+nova&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=kysyl-syr&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=juneau&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=victoria&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=laguna+de+perlas&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=mazagao&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=hotaka&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=san+patricio&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=khatanga&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=boende&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=haines+junction&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=auki&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=kalmunai&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=aflu&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=verkhnevilyuysk&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=port+augusta&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=altay&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=iglesias&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=guerrero+negro&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=san+pedro+de+macoris&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=gorontalo&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=flin+flon&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=muros&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=abashiri&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=grand+gaube&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=port+keats&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=padang&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=havelock&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=esperance&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=dalnerechensk&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=craig&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=suluq&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=sentyabrskiy&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=port+hawkesbury&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=alamosa&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=maneadero&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=okha&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=athabasca&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=mayo&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=alice+springs&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=quijingue&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=tiznit&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=dicabisagan&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=jackson&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=cap+malheureux&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=najran&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=nantucket&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=saleaula&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=ullapool&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=grand+forks&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=cabedelo&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=tecolutla&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=hassleholm&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=pitimbu&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=biltine&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=jensen+beach&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=isangel&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=bataipora&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=khonuu&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=barra+do+corda&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=lithakia&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=doka&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=hasaki&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=mulege&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=matara&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=hokitika&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=naze&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=high+rock&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=half+moon+bay&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=imst&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=aklavik&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=hambantota&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=dunedin&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=chumikan&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=two+rivers&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=tekeli&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=san+policarpo&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=san+cristobal&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=linqiong&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=port+lincoln&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=ulladulla&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=weston&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=kishapu&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=katangli&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=mvuma&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=denpasar&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=honiara&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=nogliki&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=tuatapere&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=irtyshskiy&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=farah&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=celano&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=kaka&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=hervey+bay&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=vaitape&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=pisco&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=funtua&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=hammerfest&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=touros&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=constantine&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=dolores&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=yenotayevka&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=codrington&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=gushikawa&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=alappuzha&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=vila+do+maio&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=da+lat&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=salym&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=dutlwe&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=klaksvik&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=saint+anthony&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=ituni&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=douentza&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=fevralsk&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=suixi&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=anshun&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=taltal&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=taoudenni&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=aswan&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=nortelandia&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=parana&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=assiniboia&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=awjilah&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=las+matas+de+farfan&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=necochea&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=clyde+river&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=sami&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=skiros&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=bathsheba&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=qaqortoq&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=camargo&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=constitucion&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=leningradskiy&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=puri&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=kutum&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=alofi&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=labytnangi&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=tarko-sale&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=beyneu&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=ucluelet&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=kamenka&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=sciacca&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=tuy+hoa&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=ixtapa&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=olafsvik&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=ovsyanka&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=iskateley&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=seydi&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=malakal&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=severo-kurilsk&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=berlevag&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=wolgast&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=fortuna&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=alice+town&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=shedok&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=sibut&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=lagoa&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=lang+son&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=teya&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=gurupa&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=maniitsoq&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=ostrovnoy&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=clarence+town&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=grindavik&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=mangrol&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=gamba&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=tambura&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=abu+samrah&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=green+river&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=ossora&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=tucumcari&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=ravar&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=eldikan&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=brigham+city&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=santiago+del+estero&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=mastic+beach&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=viedma&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=tsihombe&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=kourou&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=pilao+arcado&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=mopti&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=batagay&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=dianopolis&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=sao+joao+da+barra&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=gondanglegi&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=omboue&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=pacific+grove&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=burica&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=muli&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=odienne&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=gobabis&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=viligili&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    http://api.openweathermap.org/data/2.5/weather?q=sioux+lookout&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=namie&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    http://api.openweathermap.org/data/2.5/weather?q=halalo&units=IMPERIAL&mode=json&APPID=4c28215f1c71887e12ca92c10a6ac317
    Missing city weather data.......skipping
    

    C:\Users\sitra\Anaconda3\envs\PythonData\lib\site-packages\ipykernel_launcher.py:18: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
    C:\Users\sitra\Anaconda3\envs\PythonData\lib\site-packages\ipykernel_launcher.py:19: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
    C:\Users\sitra\Anaconda3\envs\PythonData\lib\site-packages\ipykernel_launcher.py:20: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
    C:\Users\sitra\Anaconda3\envs\PythonData\lib\site-packages\ipykernel_launcher.py:21: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
    




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>lat</th>
      <th>long</th>
      <th>City</th>
      <th>Country</th>
      <th>Max Temp</th>
      <th>Humidity</th>
      <th>Cloud Cover</th>
      <th>Wind Speed</th>
      <th>Date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>-15.935698</td>
      <td>-61.089880</td>
      <td>san ignacio</td>
      <td>bo</td>
      <td>79.05</td>
      <td>79.0</td>
      <td>64.0</td>
      <td>4.16</td>
      <td>1513783808</td>
    </tr>
    <tr>
      <th>1</th>
      <td>-69.686479</td>
      <td>-84.076501</td>
      <td>punta arenas</td>
      <td>cl</td>
      <td>50.00</td>
      <td>53.0</td>
      <td>20.0</td>
      <td>47.20</td>
      <td>1513782000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>8.419977</td>
      <td>136.372507</td>
      <td>airai</td>
      <td>pw</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td></td>
    </tr>
    <tr>
      <th>4</th>
      <td>61.592274</td>
      <td>-131.843796</td>
      <td>whitehorse</td>
      <td>ca</td>
      <td>8.60</td>
      <td>78.0</td>
      <td>20.0</td>
      <td>11.41</td>
      <td>1513782000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>64.212479</td>
      <td>-177.111221</td>
      <td>egvekinot</td>
      <td>ru</td>
      <td>9.30</td>
      <td>78.0</td>
      <td>68.0</td>
      <td>3.15</td>
      <td>1513783808</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Save the DataFrame as a csv
new_cities.to_csv("city_weather_data.csv", encoding="utf-8", index=False)
```


```python
# Build a scatter plot for each data type
#print(new_cities["lat"])
#print(new_cities["Max Temp"])

plt.scatter(new_cities["lat"], new_cities["Max Temp"], edgecolor="black", linewidths=1, marker="o", alpha=0.8, label="Cities")

# Incorporate the other graph properties
plt.title("City Latitude vs. Max Temperature (12-20-2017)")
plt.ylabel("Max Temperature (F)")
plt.xlabel("Latitude")
plt.grid(True)


# Save the figure
plt.savefig("MaxTemp_Latitude.png")

# Show plot
plt.show()
```


![png](output_7_0.png)



```python
# Build a scatter plot for each data type
#print(new_cities["lat"])
#print(new_cities["Max Temp"])

plt.scatter(new_cities["lat"], new_cities["Humidity"], edgecolor="black", linewidths=1, marker="o", alpha=0.8, label="Cities")

# Incorporate the other graph properties
plt.title("City Latitude vs. Humidity (12-20-2017)")
plt.ylabel("Humidity (%)")
plt.xlabel("Latitude")
plt.grid(True)


# Save the figure
plt.savefig("Humidity_Latitude.png")

# Show plot
plt.show()
```


![png](output_8_0.png)



```python
# Build a scatter plot for each data type
#print(new_cities["lat"])
#print(new_cities["Max Temp"])

plt.scatter(new_cities["lat"], new_cities["Cloud Cover"], edgecolor="black", linewidths=1, marker="o", alpha=0.8, label="Cities")

# Incorporate the other graph properties
plt.title("City Latitude vs. Cloudiness (12-20-2017)")
plt.ylabel("Cloudiness (%)")
plt.xlabel("Latitude")
plt.grid(True)


# Save the figure
plt.savefig("Cloudiness_Latitude.png")

# Show plot
plt.show()
```


![png](output_9_0.png)



```python
# Build a scatter plot for each data type
#print(new_cities["lat"])
#print(new_cities["Wind Speed])

plt.scatter(new_cities["lat"], new_cities["Wind Speed"], edgecolor="black", linewidths=1, marker="o", alpha=0.8, label="Cities")

# Incorporate the other graph properties
plt.title("City Latitude vs. Wind Speed (12-20-2017)")
plt.ylabel("Wind Speed (mph))")
plt.xlabel("Latitude")
plt.grid(True)


# Save the figure
plt.savefig("WindSpeed_Latitude.png")

# Show plot
plt.show()
```


![png](output_10_0.png)

